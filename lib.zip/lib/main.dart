import 'dart:async';

import 'package:widgets/ui/screens/home_body.dart';

import 'domain/bloc/bloc.dart';
import 'domain/bloc/record_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
 

/// The `main` function initializes the `AppState` widget which provides multiple BLoC providers for
/// managing different states in the Flutter application.

void main() => runApp(const AppState());

Timer? timeeeer;

class AppState extends StatelessWidget {
  const AppState({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => IconButtomCubit(),
          lazy: false,
        ),
        BlocProvider(
          create: (context) => RecorderVoice(),
          lazy: false,
        ),
    
      ],
      child: const MyApp(),
    );
  }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Material App',
      home: HomeBody(),
    );
  }
}
