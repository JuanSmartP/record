import '../../domain/bloc/bloc.dart';
import 'package:flutter/material.dart';

import '../../domain/bloc/record_bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

/// The `HomeBody` class in Dart represents a stateful widget for a voice recorder app with
/// functionality for recording and playing audio.

class HomeBody extends StatefulWidget {
  HomeBody({super.key});

  @override
  State<HomeBody> createState() => _HomeBodyState();
}

class _HomeBodyState extends State<HomeBody> {
  final recor = RecorderVoice();

  String recordDuration = "00:00";

  @override
  void initState() {
    recor.recordvoice;

    super.initState();
  }
 

  @override
  Widget build(BuildContext context) {
    final iconButtom = context.watch<IconButtomCubit>();
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Voice Recorder'),
      ),
      body: ListView(
        children: [
          BlocBuilder<IconButtomCubit, ButtomIconState>(
            bloc: iconButtom,
            builder: (context, state) {
              return CustomBody(
                state: state,
                iconButtom: iconButtom,
                recordDuration: recordDuration,
              );
            },
          ),
        ],
      ),
    );
  }
}

/// The `CustomBody` class in Dart is a stateful widget that displays a record duration and a button
/// that toggles between recording and stopping recording audio.

class CustomBody extends StatefulWidget {
  String recordDuration;
  final IconButtomCubit iconButtom;
  final ButtomIconState state;

  CustomBody({
    super.key,
    required this.recordDuration,
    required this.iconButtom,
    required this.state,
  });

  @override
  State<CustomBody> createState() => _CustomBodyState();
}

class _CustomBodyState extends State<CustomBody> {
  @override
  Widget build(BuildContext context) {
    final recor = context.watch<RecorderVoice>();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 20),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: FloatingActionButton(
              onPressed: () {
                widget.iconButtom.changeIcon();
                recor.starStopVoiceRecord();
              },
              child: widget.state == ButtomIconState.icon1
                  ? const Icon(Icons.mic)
                  : const Icon(Icons.stop),
            ),
          ),
        ],
      ),
    );
  }
}
