import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:widgets/domain/peticiones/audio.dart';
import 'package:widgets/domain/repositori/inicalizar.dart';
import 'package:record/record.dart';
import 'package:widgets/main.dart';

/// The `RecorderVoice` class in Dart manages recording and converting audio files to Base64 format.

bool isRecording = false;

class RecorderVoice extends Cubit<bool> {
  RecorderVoice() : super(isRecording);

  //Se instancia la variable de tipo Record()
  //Para luego ser inicializada en el Home_body

  final recordvoice = Record();

  //Metodo para iniciar a grabar
  //Metodo para iniciar a grabar
  Future<void> starRecord() async {
    await recordvoice.start();
  }

  //Metodo para detener la grabacion
  //Tambien se encarga de guardar el archivo y entregar el path del archivo
  Future stopRecording() async {
    try {
      String? path = await recordvoice.stop();
      String audioPath = path!;
      print('interno-------------------->${audioPath}');
      $event.evento(audioPath);
      timeeeer?.cancel();
      timeeeer = null;

      convertBase64(path);
    } catch (e) {
      Exception(e);
    }
  }

  //Establece la duracion del audio en 20sg
  void setTimeOut() {
    const duration = Duration(seconds: 20);

    Timer(duration, () {
      stopRecording();
    });
  }

  //Se encarga de iniciar o detener la grabacion
  Future<void> starStopVoiceRecord() async {
    //Inicia la grabacion
    if (!isRecording && await recordvoice.hasPermission()) {
      starRecord();
      setTimeOut();
    }
    isRecording = !isRecording;
    
  }

  //Convertir audio a Base64
  Future<void> convertBase64(path) async {
    if (path != null) {
      File file = File(path);
      file.openRead();
      List<int> fileBytes = await file.readAsBytes();
      String base64String = base64.encode(fileBytes);

      //log(' BASE64====> data:audio/mp3;base64,${base64String}');

      final peticiones = Peticiones();
      peticiones.sendAudio('data:audio/mp3base64,' + base64String);
    } else {
      print('No Path');
    }
  }
}
