import 'package:flutter_bloc/flutter_bloc.dart';

/// The `IconButtomCubit` class is a Cubit that manages the state of a button icon between two states.

enum ButtomIconState { icon1, icon2 }

class IconButtomCubit extends Cubit<ButtomIconState> {
  IconButtomCubit() : super(ButtomIconState.icon1);

  void changeIcon() {
    emit(state == ButtomIconState.icon1
        ? ButtomIconState.icon2
        : ButtomIconState.icon1);
  }
}
