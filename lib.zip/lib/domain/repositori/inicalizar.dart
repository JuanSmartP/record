import 'package:widgets/domain/repositori/function.dart';

/// This code snippet is declaring a new event and initializing it with the result of
/// calling the `event()` function. The `event()` function is likely defined elsewhere in the codebase
/// and is being used to create or handle events in the application.

event $event = event();
