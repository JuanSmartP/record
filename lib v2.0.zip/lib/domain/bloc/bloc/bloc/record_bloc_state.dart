part of 'record_bloc_bloc.dart';

sealed class RecordBlocState extends Equatable {
  const RecordBlocState();
  
  @override
  List<Object> get props => [];
}

final class Recording extends RecordBlocState {



}
