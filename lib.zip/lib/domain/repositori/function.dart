import 'package:events_emitter/events_emitter.dart';

/// The class `event` in Dart defines an event emitter with a method `evento` to emit events with data.
class event {
  final events = EventEmitter();

  void evento(String data) {
    events.emit('path', data);
  }
}