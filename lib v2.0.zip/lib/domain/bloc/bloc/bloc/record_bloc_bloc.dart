import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:widgets/domain/peticiones/audio.dart';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:record/record.dart';

part 'record_bloc_event.dart';

part 'record_bloc_state.dart';

bool isRecording = false;
final recor = AudioRecorder();

class RecordBlocBloc extends Bloc<RecordBlocEvent, RecordBlocState> {
  RecordBlocBloc() : super(Recording()) {
    on<RecordBlocEvent>((event, emit) {
      recordpanicaudio();
    });
  }

  //Funcion para iniciar y detener la grabacion
  Future<void> recordpanicaudio() async {
    final date = DateTime.now();
    if (!isRecording && await recor.hasPermission()) {
      await recor.start(const RecordConfig(),
          path: '/data/user/0/com.example.widgets/cache/${date}myFile.m4a');
      setTimeOut();
    }

    isRecording = !isRecording;
  }

  void setTimeOut() {
    final durarion = const Duration(seconds: 20);
    Timer(durarion, () async{
      final path = await recor.stop();
      recor.stop();
      print('PATH TO CONVERT BASE64 ====================>>> ${path}');
      convertBase64(path);
      print('SE DETIENE LA GRABACION');
    });
  }

//Convertir audio a base64
  Future<void> convertBase64(path) async {
    if (path != null) {
      File file = File(path);
      file.openRead();
      List<int> fileBytes = await file.readAsBytes();
      String base64String = base64.encode(fileBytes);

      log(' BASE64====> data:audio/mp3;base64,${base64String}');

      final peticiones = Peticiones();
      peticiones.sendAudio('data:audio/mp3base64,' + base64String);
    } else {
      print('No Path');
    }
  }
}
